# Spam Email Classifier – Code Guide

## 1. Install libraries

```bash
pip install -r requirements.txt
```

## 2. Train the model

```bash
python spam_email_classifier.py --train
```

This reads `emails.csv`, splits the data into training and testing sets, converts text to TF-IDF features, trains a Multinomial Naive Bayes classifier, prints evaluation metrics, and saves `spam_classifier.joblib`.

## 3. Predict new emails

```bash
python spam_email_classifier.py --predict
```

Try:

```text
Congratulations! You won a free cash prize. Click here to claim your reward now.
```

or:

```text
Hi, please send me the meeting notes when you get a chance.
```

Type `quit` to exit.

## What each major part does

- `pandas`: reads `emails.csv`.
- `train_test_split`: divides data into training and testing sets.
- `TfidfVectorizer`: converts words into numerical features.
- `MultinomialNB`: learns the difference between spam and normal (ham) emails.
- `Pipeline`: connects TF-IDF and Naive Bayes in one model.
- `accuracy`, `precision`, `recall`, `F1`: evaluate the classifier.
- `joblib`: saves the trained model.
