"""
Spam Email Classifier
---------------------
Single-file version of the internship project.

Run:
    pip install -r requirements.txt
    python spam_email_classifier.py --train
    python spam_email_classifier.py --predict
"""

from pathlib import Path
import argparse
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "emails.csv"
MODEL_PATH = ROOT / "spam_classifier.joblib"


def build_model():
    return Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english", ngram_range=(1, 2), sublinear_tf=True)),
        ("nb", MultinomialNB(alpha=0.5)),
    ])


def train_model():
    df = pd.read_csv(DATA_PATH)

    if not {"label", "text"}.issubset(df.columns):
        raise ValueError("Dataset must contain 'label' and 'text' columns.")

    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label"], test_size=0.20, random_state=42, stratify=df["label"]
    )

    model = build_model()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    accuracy = accuracy_score(y_test, predictions)
    precision = precision_score(y_test, predictions, pos_label="spam")
    recall = recall_score(y_test, predictions, pos_label="spam")
    f1 = f1_score(y_test, predictions, pos_label="spam")
    cm = confusion_matrix(y_test, predictions, labels=["ham", "spam"])

    joblib.dump(model, MODEL_PATH)

    print("\n===== MODEL PERFORMANCE =====")
    print(f"Accuracy :  {accuracy:.4f}")
    print(f"Precision:  {precision:.4f}")
    print(f"Recall   :  {recall:.4f}")
    print(f"F1 Score :  {f1:.4f}")
    print("\nConfusion Matrix [ham, spam]:")
    print(cm)
    print("\nClassification Report:")
    print(classification_report(y_test, predictions, labels=["ham", "spam"]))
    print(f"Model saved to: {MODEL_PATH}")


def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Model not found. Run: python spam_email_classifier.py --train")
    return joblib.load(MODEL_PATH)


def predict_email(model, text):
    label = model.predict([text])[0]
    probabilities = model.predict_proba([text])[0]
    classes = list(model.classes_)
    confidence = float(probabilities[classes.index(label)])
    return label, confidence


def interactive_prediction():
    model = load_model()
    print("\n" + "=" * 60)
    print("           SPAM EMAIL CLASSIFIER")
    print("=" * 60)
    print("Enter an email message and press Enter.")
    print("Type 'quit' to stop.\n")

    while True:
        text = input("Email: ").strip()
        if text.lower() in {"quit", "exit"}:
            print("Program ended.")
            break
        if not text:
            print("Please enter some text.\n")
            continue

        label, confidence = predict_email(model, text)
        result = "SPAM" if label == "spam" else "NOT SPAM (HAM)"
        print(f"Prediction : {result}")
        print(f"Confidence : {confidence * 100:.2f}%\n")


def main():
    parser = argparse.ArgumentParser(description="Spam Email Classifier")
    parser.add_argument("--train", action="store_true", help="Train and save the model")
    parser.add_argument("--predict", action="store_true", help="Start interactive prediction")
    args = parser.parse_args()

    if args.train:
        train_model()
    elif args.predict:
        interactive_prediction()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
