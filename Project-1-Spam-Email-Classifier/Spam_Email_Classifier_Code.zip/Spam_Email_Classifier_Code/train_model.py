from pathlib import Path
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data' / 'emails.csv'
MODEL_DIR = ROOT / 'artifacts'
MODEL_DIR.mkdir(exist_ok=True)
MODEL_PATH = MODEL_DIR / 'spam_classifier.joblib'
METRICS_PATH = MODEL_DIR / 'metrics.txt'


def main():
    df = pd.read_csv(DATA)
    if not {'label', 'text'}.issubset(df.columns):
        raise ValueError('Dataset must contain label and text columns.')

    X_train, X_test, y_train, y_test = train_test_split(
        df['text'], df['label'], test_size=0.20, random_state=42, stratify=df['label']
    )

    model = Pipeline([
        ('tfidf', TfidfVectorizer(lowercase=True, stop_words='english', ngram_range=(1, 2), sublinear_tf=True)),
        ('nb', MultinomialNB(alpha=0.5)),
    ])
    model.fit(X_train, y_train)

    pred = model.predict(X_test)
    acc = accuracy_score(y_test, pred)
    precision = precision_score(y_test, pred, pos_label='spam')
    recall = recall_score(y_test, pred, pos_label='spam')
    f1 = f1_score(y_test, pred, pos_label='spam')
    cm = confusion_matrix(y_test, pred, labels=['ham', 'spam'])

    joblib.dump(model, MODEL_PATH)
    report = classification_report(y_test, pred, labels=['ham', 'spam'])
    metrics = (
        f'Accuracy: {acc:.4f}\n'
        f'Precision (spam): {precision:.4f}\n'
        f'Recall (spam): {recall:.4f}\n'
        f'F1-score (spam): {f1:.4f}\n'
        f'Confusion Matrix [[TN, FP], [FN, TP]]: {cm.tolist()}\n\n'
        f'Classification Report:\n{report}'
    )
    METRICS_PATH.write_text(metrics, encoding='utf-8')

    print(metrics)
    print(f'\nSaved model to: {MODEL_PATH}')

if __name__ == '__main__':
    main()
