from pathlib import Path
import joblib

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / 'artifacts' / 'spam_classifier.joblib'


def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError('Model file not found. Run: python train_model.py')
    return joblib.load(MODEL_PATH)


def predict_email(model, text: str):
    label = model.predict([text])[0]
    probs = model.predict_proba([text])[0]
    classes = list(model.classes_)
    confidence = float(probs[classes.index(label)])
    return label, confidence


def main():
    model = load_model()
    print('=' * 60)
    print('SPAM EMAIL CLASSIFIER')
    print('Type an email message and press Enter.')
    print('Type quit to exit.')
    print('=' * 60)
    while True:
        text = input('\nEmail: ').strip()
        if text.lower() in {'quit', 'exit'}:
            print('Exiting...')
            break
        if not text:
            print('Please enter some email text.')
            continue
        label, confidence = predict_email(model, text)
        status = 'SPAM' if label == 'spam' else 'NOT SPAM (HAM)'
        print(f'Prediction : {status}')
        print(f'Confidence : {confidence * 100:.2f}%')

if __name__ == '__main__':
    main()
