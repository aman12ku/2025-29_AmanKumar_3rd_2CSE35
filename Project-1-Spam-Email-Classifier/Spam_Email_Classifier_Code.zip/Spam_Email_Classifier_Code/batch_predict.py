from pathlib import Path
import argparse
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parent
MODEL = ROOT / 'artifacts' / 'spam_classifier.joblib'

parser = argparse.ArgumentParser(description='Predict spam/ham labels for a CSV file.')
parser.add_argument('input_csv', help='CSV containing a text column')
parser.add_argument('-o', '--output', default='predictions.csv')
args = parser.parse_args()

df = pd.read_csv(args.input_csv)
if 'text' not in df.columns:
    raise ValueError("Input CSV must contain a 'text' column.")
model = joblib.load(MODEL)
df['prediction'] = model.predict(df['text'])
df['confidence'] = model.predict_proba(df['text']).max(axis=1)
df.to_csv(args.output, index=False)
print(f'Saved predictions to {args.output}')
