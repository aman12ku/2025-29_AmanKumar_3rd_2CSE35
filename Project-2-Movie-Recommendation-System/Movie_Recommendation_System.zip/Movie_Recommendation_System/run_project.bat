@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
python code\movie_recommender.py
pause
