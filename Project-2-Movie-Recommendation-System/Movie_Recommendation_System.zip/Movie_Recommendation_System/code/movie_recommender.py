"""Movie Recommendation System - Content Based Filtering.

Run:
    python code/movie_recommender.py

The project represents each movie using its genre, keywords and description,
then uses TF-IDF and cosine similarity to recommend similar movies.
"""

from pathlib import Path
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_FILE = BASE_DIR / "data" / "movies.csv"
MODEL_DIR = BASE_DIR / "artifacts"
VECTORIZER_FILE = MODEL_DIR / "tfidf_vectorizer.joblib"
MATRIX_FILE = MODEL_DIR / "tfidf_matrix.joblib"
MOVIES_FILE = MODEL_DIR / "movies_processed.csv"


def load_movies():
    if not DATA_FILE.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_FILE}")
    df = pd.read_csv(DATA_FILE)
    required = {"title", "genre", "keywords", "description", "rating"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    df = df.dropna(subset=["title", "genre", "keywords", "description"]).reset_index(drop=True)
    df["features"] = (
        df["genre"].str.replace("|", " ", regex=False) + " "
        + df["keywords"].str.replace("|", " ", regex=False) + " "
        + df["description"]
    ).str.lower()
    return df


def build_system(df):
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(df["features"])
    return vectorizer, matrix


def save_system(df, vectorizer, matrix):
    MODEL_DIR.mkdir(exist_ok=True)
    joblib.dump(vectorizer, VECTORIZER_FILE)
    joblib.dump(matrix, MATRIX_FILE)
    df.drop(columns=["features"]).to_csv(MOVIES_FILE, index=False)


def train_system():
    df = load_movies()
    vectorizer, matrix = build_system(df)
    save_system(df, vectorizer, matrix)
    print("Movie recommendation system built successfully.")
    print(f"Movies available: {len(df)}")
    print(f"TF-IDF features: {matrix.shape[1]}")
    print(f"Saved model files to: {MODEL_DIR}")


def load_system():
    if not (VECTORIZER_FILE.exists() and MATRIX_FILE.exists() and MOVIES_FILE.exists()):
        print("Saved system not found. Building it now...\n")
        train_system()
    vectorizer = joblib.load(VECTORIZER_FILE)
    matrix = joblib.load(MATRIX_FILE)
    df = pd.read_csv(MOVIES_FILE)
    return df, vectorizer, matrix


def recommend(title, df, matrix, top_n=5):
    matches = df.index[df["title"].str.lower() == title.lower()].tolist()
    if not matches:
        # Fuzzy-ish fallback using substring search for easier demos.
        matches = df.index[df["title"].str.lower().str.contains(title.lower(), regex=False)].tolist()
    if not matches:
        return None, []

    idx = matches[0]
    similarities = cosine_similarity(matrix[idx], matrix).flatten()
    ranked = similarities.argsort()[::-1]
    ranked = [i for i in ranked if i != idx][:top_n]
    results = df.loc[ranked, ["title", "genre", "rating"]].copy()
    results["similarity"] = similarities[ranked]
    return df.loc[idx, "title"], results


def show_recommendations():
    df, _, matrix = load_system()
    print("\n" + "=" * 65)
    print("                 MOVIE RECOMMENDATION SYSTEM")
    print("=" * 65)
    print(f"Movies in dataset: {len(df)}")
    print("Type a movie title to get similar movies.")
    print("Type 'list' to view available titles or 'quit' to exit.\n")

    while True:
        query = input("Movie: ").strip()
        if query.lower() in {"quit", "exit"}:
            print("Program ended.")
            break
        if query.lower() == "list":
            print("\n".join(df["title"].tolist()))
            print()
            continue
        if not query:
            continue

        selected, results = recommend(query, df, matrix, top_n=5)
        if selected is None:
            print("Movie not found. Type 'list' to see available titles.\n")
            continue

        print(f"\nRecommendations similar to: {selected}")
        print("-" * 65)
        for rank, (_, row) in enumerate(results.iterrows(), start=1):
            print(f"{rank}. {row['title']}")
            print(f"   Genre: {row['genre'].replace('|', ', ')}")
            print(f"   Rating: {row['rating']:.1f}")
            print(f"   Similarity: {row['similarity'] * 100:.1f}%\n")


def main():
    show_recommendations()


if __name__ == "__main__":
    main()
