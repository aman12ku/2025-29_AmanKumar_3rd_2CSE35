from movie_recommender import load_movies, build_system, save_system

if __name__ == "__main__":
    df = load_movies()
    vectorizer, matrix = build_system(df)
    save_system(df, vectorizer, matrix)
    print(f"Built recommendation system for {len(df)} movies.")
