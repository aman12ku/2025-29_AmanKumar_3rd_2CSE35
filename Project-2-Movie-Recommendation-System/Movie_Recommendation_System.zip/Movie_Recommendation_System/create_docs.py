from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'docs' / 'Movie_Recommendation_System_Report.docx'

def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)

def add_heading(doc, text, level=1):
    p = doc.add_heading(text, level=level)
    return p

def add_code(doc, text):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.name = 'Consolas'
    r.font.size = Pt(9)
    return p

doc = Document()
sec = doc.sections[0]
sec.top_margin = Inches(0.65)
sec.bottom_margin = Inches(0.65)
sec.left_margin = Inches(0.75)
sec.right_margin = Inches(0.75)

styles = doc.styles
styles['Normal'].font.name = 'Aptos'
styles['Normal'].font.size = Pt(10.5)

# Cover
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('MOVIE RECOMMENDATION SYSTEM')
r.bold = True; r.font.size = Pt(24)
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Internship Project Report'); r.font.size = Pt(16)

for _ in range(3): doc.add_paragraph()
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run('A Content-Based Filtering Approach Using TF-IDF and Cosine Similarity').bold = True
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run('Technology: Python | Pandas | scikit-learn | Joblib')

for _ in range(6): doc.add_paragraph()
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run('Prepared for Internship Submission').italic = True

doc.add_page_break()

# TOC-like contents
add_heading(doc, 'Table of Contents', 1)
for item in [
    '1. Abstract','2. Introduction','3. Problem Statement','4. Objectives',
    '5. Technologies Used','6. System Design and Methodology','7. Implementation',
    '8. Results and Discussion','9. Advantages and Limitations','10. Future Scope',
    '11. Conclusion','12. Viva Questions and Answers','13. Project Structure','14. How to Run'
]:
    doc.add_paragraph(item)

doc.add_page_break()

add_heading(doc, '1. Abstract', 1)
doc.add_paragraph(
    'A movie recommendation system helps users discover films that match their interests. '
    'This project implements a simple content-based recommendation system in Python. '
    'Each movie is represented by its genre, keywords and description. Text is converted into '
    'numerical vectors with TF-IDF, and cosine similarity is used to compare movies. '
    'For a selected movie, the system returns the five most similar movies along with genre, rating and similarity score. '
    'The project is intentionally small and transparent so that the complete workflow can be understood and demonstrated easily.'
)

add_heading(doc, '2. Introduction', 1)
doc.add_paragraph(
    'Recommendation systems are widely used in digital platforms to help users find relevant content. '
    'A content-based system recommends items that are similar to an item the user already likes. '
    'Unlike collaborative filtering, it does not require a large history of users and ratings. '
    'This makes content-based filtering suitable for a small academic demonstration.'
)

add_heading(doc, '3. Problem Statement', 1)
doc.add_paragraph(
    'A user may know the name of one movie they enjoy but may not know what to watch next. '
    'The goal of this project is to build a program that takes a movie title as input and recommends similar movies automatically.'
)

add_heading(doc, '4. Objectives', 1)
for x in [
    'Create a small structured movie dataset for demonstration.',
    'Represent movie information as text features.',
    'Convert text into TF-IDF vectors.',
    'Measure similarity between movies using cosine similarity.',
    'Display the top five recommendations interactively.',
    'Provide a simple runnable project suitable for internship demonstration.'
]: doc.add_paragraph(x, style='List Bullet')

add_heading(doc, '5. Technologies Used', 1)
table = doc.add_table(rows=1, cols=3); table.alignment = WD_TABLE_ALIGNMENT.CENTER; table.style = 'Table Grid'
headers = ['Technology', 'Purpose', 'Why Used']
for i,h in enumerate(headers):
    table.rows[0].cells[i].text = h; set_cell_shading(table.rows[0].cells[i], 'D9EAF7')
for row in [
    ('Python', 'Programming language', 'Simple and widely used for data science'),
    ('Pandas', 'Dataset handling', 'Reads and processes CSV data'),
    ('scikit-learn', 'Machine learning', 'Provides TF-IDF vectorizer and similarity tools'),
    ('Joblib', 'Model persistence', 'Saves the processed vectorizer and matrix'),
    ('CSV', 'Data storage', 'Easy to inspect and edit for an academic project')
]:
    cells = table.add_row().cells
    for i,v in enumerate(row): cells[i].text = v

add_heading(doc, '6. System Design and Methodology', 1)
for x in [
    'Step 1 – Data collection: The bundled dataset contains 40 movies with title, genre, keywords, description and rating.',
    'Step 2 – Feature preparation: Genre and keywords are converted to text and combined with the description.',
    'Step 3 – TF-IDF: Each movie is converted into a weighted vector based on words and two-word phrases.',
    'Step 4 – Cosine similarity: Similarity is computed between the selected movie vector and all other movie vectors.',
    'Step 5 – Ranking: Movies are sorted by similarity score and the top five are displayed.',
    'Step 6 – User interaction: The terminal accepts a movie title, prints recommendations, supports a title list, and exits on quit.'
]: doc.add_paragraph(x, style='List Number')

add_heading(doc, '6.1 TF-IDF', 2)
doc.add_paragraph(
    'TF-IDF stands for Term Frequency–Inverse Document Frequency. It gives greater weight to words that are useful for distinguishing one movie from another, while reducing the influence of words that occur broadly across many descriptions. In this project, TF-IDF turns movie text into numerical feature vectors.'
)

add_heading(doc, '6.2 Cosine Similarity', 2)
doc.add_paragraph(
    'Cosine similarity compares the angle between two vectors. A value closer to 1 indicates that the feature vectors point in a more similar direction. The system uses these scores to rank candidate movies.'
)

add_heading(doc, '7. Implementation', 1)
doc.add_paragraph('Core Python logic:')
add_code(doc, '''vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))\nmatrix = vectorizer.fit_transform(df["features"])\nsimilarities = cosine_similarity(matrix[idx], matrix).flatten()\nranked = similarities.argsort()[::-1]''')

doc.add_paragraph('The project separates data, source code, saved artifacts and documentation. The main executable file is `code/movie_recommender.py` and the dataset is `data/movies.csv` in the project folder.')

add_heading(doc, '8. Results and Discussion', 1)
doc.add_paragraph('A sample run using the bundled dataset produced the following recommendations:')
res_table = doc.add_table(rows=1, cols=4); res_table.style='Table Grid'; res_table.alignment=WD_TABLE_ALIGNMENT.CENTER
for i,h in enumerate(['Input Movie','Rank','Recommendation','Similarity']):
    res_table.rows[0].cells[i].text=h; set_cell_shading(res_table.rows[0].cells[i],'D9EAF7')
samples = [
    ('Inception','1','Interstellar','7.67%'),
    ('Inception','2','Avengers: Endgame','7.21%'),
    ('Inception','3','Guardians of the Galaxy','4.65%'),
    ('The Dark Knight','1','John Wick','7.96%'),
    ('The Dark Knight','2','Iron Man','5.66%'),
    ('Toy Story','1','The Intouchables','10.71%')
]
for row in samples:
    cells=res_table.add_row().cells
    for i,v in enumerate(row): cells[i].text=v

doc.add_paragraph(
    'The results demonstrate the intended behavior: movies sharing important terms, genres or themes with the selected title tend to receive higher similarity scores. The score is a text-feature similarity rather than a prediction of user satisfaction.'
)

add_heading(doc, '9. Advantages and Limitations', 1)
doc.add_paragraph('Advantages', style='Heading 2')
for x in ['Simple to understand and demonstrate.', 'No large user database is required.', 'Recommendations are explainable through text similarity.', 'Works offline with the bundled dataset.']: doc.add_paragraph(x, style='List Bullet')
doc.add_paragraph('Limitations', style='Heading 2')
for x in ['The dataset is small and created for academic demonstration.', 'It does not learn from real user behavior or ratings.', 'Recommendations depend on the quality of the movie descriptions and keywords.', 'It cannot capture a user\'s personal preferences beyond the selected movie.']: doc.add_paragraph(x, style='List Bullet')

add_heading(doc, '10. Future Scope', 1)
for x in [
    'Use a larger real-world movie dataset.',
    'Add user ratings and build a hybrid recommender.',
    'Add collaborative filtering.',
    'Develop a web interface using Flask or Streamlit.',
    'Add filters for genre, language, year and rating.',
    'Evaluate recommendations with user-based metrics such as Precision@K and Recall@K.'
]: doc.add_paragraph(x, style='List Bullet')

add_heading(doc, '11. Conclusion', 1)
doc.add_paragraph(
    'The Movie Recommendation System demonstrates a complete introductory recommendation workflow. '
    'The project combines text preprocessing, TF-IDF feature extraction and cosine similarity to produce ranked movie recommendations. '
    'Because the implementation is small and transparent, it is suitable for learning, internship submission and a basic live demonstration.'
)

add_heading(doc, '12. Viva Questions and Answers', 1)
qa = [
    ('What is a recommendation system?', 'A system that suggests relevant items to users based on item features, user behavior, or both.'),
    ('Which recommendation technique is used?', 'Content-based filtering.'),
    ('Why is TF-IDF used?', 'To convert text into numerical feature vectors while giving useful importance to words.'),
    ('What is cosine similarity?', 'A measure of similarity between vectors based on the cosine of the angle between them.'),
    ('Why not use collaborative filtering?', 'It would require user-item interaction data; this project intentionally uses only movie content.'),
    ('What is the input?', 'A movie title typed by the user.'),
    ('What is the output?', 'The five most similar movies with genre, rating and similarity score.'),
    ('Is the system production-ready?', 'No. It is an academic demo with a small bundled dataset.'),
]
for q,a in qa:
    p=doc.add_paragraph(); p.add_run('Q: '+q).bold=True
    doc.add_paragraph('A: '+a)

add_heading(doc, '13. Project Structure', 1)
add_code(doc, '''Movie_Recommendation_System/\n|-- code/\n|   |-- movie_recommender.py\n|   `-- train_model.py\n|-- data/\n|   `-- movies.csv\n|-- artifacts/\n|-- docs/\n|-- slides/\n|-- requirements.txt\n|-- README.md\n`-- run_project.bat''')

add_heading(doc, '14. How to Run', 1)
doc.add_paragraph('Open a terminal in the project folder and run:')
add_code(doc, 'pip install -r requirements.txt\npython code/train_model.py\npython code/movie_recommender.py')
doc.add_paragraph('Then type a movie title such as `Inception`, `Toy Story`, or `The Dark Knight`. Type `list` to view all available titles and `quit` to exit.')

doc.save(OUT)
print(OUT)
