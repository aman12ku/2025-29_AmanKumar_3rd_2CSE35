# Movie Recommendation System

A simple content-based movie recommendation system built with Python, Pandas and scikit-learn.

## How it works
1. Load a small movie dataset.
2. Combine genre, keywords and description into one text feature.
3. Convert text into TF-IDF vectors.
4. Calculate cosine similarity between movies.
5. Show the top 5 most similar movies.

## Run
```bash
pip install -r requirements.txt
python code/train_model.py
python code/movie_recommender.py
```

Inside the program, enter a title such as `Inception`, `Toy Story`, or `The Dark Knight`.

Type `list` to see all titles and `quit` to exit.

## Notes
This is an academic/demo system using a bundled sample dataset. It is not a production recommender and does not use real user history or live movie catalogs.
