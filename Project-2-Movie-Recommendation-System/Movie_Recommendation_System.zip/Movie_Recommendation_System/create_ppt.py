from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor

ROOT = Path(__file__).resolve().parent
OUT = ROOT/'slides'/'Movie_Recommendation_System_Presentation.pptx'
prs = Presentation(); prs.slide_width=Inches(13.333); prs.slide_height=Inches(7.5)

NAVY = RGBColor(25, 48, 75)
LIGHT = RGBColor(240, 244, 248)
ACCENT = RGBColor(52, 104, 156)
WHITE = RGBColor(255,255,255)
DARK = RGBColor(40,40,40)

def add_title(slide, title, subtitle=None):
    tb=slide.shapes.add_textbox(Inches(0.65), Inches(0.35), Inches(12), Inches(0.7))
    p=tb.text_frame.paragraphs[0]; p.text=title; p.font.size=Pt(28); p.font.bold=True; p.font.color.rgb=NAVY
    if subtitle:
        sb=slide.shapes.add_textbox(Inches(0.68), Inches(1.03), Inches(11.7), Inches(0.45))
        p=sb.text_frame.paragraphs[0]; p.text=subtitle; p.font.size=Pt(13); p.font.color.rgb=DARK

def add_bullets(slide, items, x=0.9,y=1.45,w=11.4,h=5.3, size=21):
    tb=slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf=tb.text_frame; tf.word_wrap=True
    for i,item in enumerate(items):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph(); p.text=item; p.font.size=Pt(size); p.font.color.rgb=DARK; p.space_after=Pt(10); p.level=0
        p.text = '• ' + p.text
    return tb

def footer(slide, n):
    sh=slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0), Inches(7.18), Inches(13.333), Inches(0.32)); sh.fill.solid(); sh.fill.fore_color.rgb=NAVY; sh.line.fill.background()
    tb=slide.shapes.add_textbox(Inches(11.9), Inches(7.19), Inches(0.8), Inches(0.22)); p=tb.text_frame.paragraphs[0]; p.text=str(n); p.font.size=Pt(10); p.font.color.rgb=WHITE; p.alignment=PP_ALIGN.RIGHT

# 1
slide=prs.slides.add_slide(prs.slide_layouts[6]); slide.background.fill.solid(); slide.background.fill.fore_color.rgb=LIGHT
box=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(1.1), Inches(11.7), Inches(4.7)); box.fill.solid(); box.fill.fore_color.rgb=WHITE; box.line.color.rgb=ACCENT
for text,y,sz,bold,col in [('MOVIE RECOMMENDATION SYSTEM',1.8,34,True,NAVY),('Content-Based Filtering with TF-IDF and Cosine Similarity',2.75,22,False,ACCENT),('Python Internship Project',3.55,18,False,DARK),('Pandas • scikit-learn • Joblib',4.15,16,False,DARK)]:
    tb=slide.shapes.add_textbox(Inches(1.15), Inches(y), Inches(11), Inches(0.7)); p=tb.text_frame.paragraphs[0]; p.text=text; p.font.size=Pt(sz); p.font.bold=bold; p.font.color.rgb=col; p.alignment=PP_ALIGN.CENTER
footer(slide,1)

# 2
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'1. Introduction')
add_bullets(slide,[
    'Recommendation systems help users discover relevant content.',
    'This project uses content-based filtering: similar movies are recommended based on movie information.',
    'It is designed as a small, transparent academic project that can run offline.',
    'No large user-history database is required.'
]); footer(slide,2)

# 3
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'2. Problem Statement & Objectives')
add_bullets(slide,[
    'Problem: a user knows one movie they like but needs suggestions for what to watch next.',
    'Build a program that accepts a movie title and returns similar movies.',
    'Use genre, keywords and description as movie features.',
    'Rank recommendations using cosine similarity.',
    'Provide a simple interactive terminal application.'
]); footer(slide,3)

# 4 methodology diagram
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'3. System Workflow')
steps=['Movie CSV','Feature Text','TF-IDF','Cosine Similarity','Top 5 Recommendations']
xs=[0.5,3.05,5.6,8.05,10.55]
for i,(s,x) in enumerate(zip(steps,xs)):
    sh=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(2.3), Inches(2.15), Inches(1.2)); sh.fill.solid(); sh.fill.fore_color.rgb=WHITE; sh.line.color.rgb=ACCENT
    tb=slide.shapes.add_textbox(Inches(x+0.1), Inches(2.48), Inches(1.95), Inches(0.7)); p=tb.text_frame.paragraphs[0]; p.text=s; p.font.size=Pt(18); p.font.bold=True; p.font.color.rgb=NAVY; p.alignment=PP_ALIGN.CENTER
    if i<4:
        ar=slide.shapes.add_shape(MSO_SHAPE.CHEVRON, Inches(x+2.17), Inches(2.62), Inches(0.65), Inches(0.55)); ar.fill.solid(); ar.fill.fore_color.rgb=ACCENT; ar.line.fill.background()
add_bullets(slide,['Features are built by combining genre + keywords + description.','The selected movie is compared with every other movie.'],x=1.2,y=4.2,w=10.8,h=1.8,size=18); footer(slide,4)

# 5 tfidf
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'4. Key Technique: TF-IDF')
add_bullets(slide,[
    'TF-IDF means Term Frequency–Inverse Document Frequency.',
    'It converts text into numerical feature vectors.',
    'Words that are useful for distinguishing movies receive more importance.',
    'The project also uses unigrams and bigrams (1–2 word phrases).'
]); footer(slide,5)

# 6 cosine
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'5. Key Technique: Cosine Similarity')
add_bullets(slide,[
    'Cosine similarity compares two TF-IDF vectors.',
    'A larger value means the movie descriptions/features are more similar.',
    'The system sorts all candidates by similarity and selects the top five.',
    'Similarity is a text-feature score, not a guarantee that a user will like the movie.'
]); footer(slide,6)

# 7 implementation
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'6. Implementation')
add_bullets(slide,[
    'Language: Python',
    'Pandas: CSV loading and data preparation',
    'scikit-learn: TF-IDF and cosine similarity',
    'Joblib: saving processed model artifacts',
    'Interactive terminal input: title → recommendations'
]); footer(slide,7)

# 8 results table-like
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'7. Sample Results','Bundled academic dataset: 40 movies')
rows=[('Input','Top Recommendation','Similarity'),('Inception','Interstellar','7.67%'),('The Dark Knight','John Wick','7.96%'),('Toy Story','The Intouchables','10.71%')]
for r,(a,b,c) in enumerate(rows):
    y=1.6+r*1.05
    for x,w,text in [(0.8,4.1,a),(4.95,4.8,b),(9.85,2.5,c)]:
        sh=slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(0.85)); sh.fill.solid(); sh.fill.fore_color.rgb=(NAVY if r==0 else WHITE); sh.line.color.rgb=ACCENT
        tb=slide.shapes.add_textbox(Inches(x+0.1),Inches(y+0.18),Inches(w-0.2),Inches(0.5)); p=tb.text_frame.paragraphs[0]; p.text=text; p.font.size=Pt(17); p.font.bold=(r==0); p.font.color.rgb=(WHITE if r==0 else DARK); p.alignment=PP_ALIGN.CENTER
footer(slide,8)

# 9 structure and run
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'8. Project Structure & Execution')
add_bullets(slide,[
    'code/movie_recommender.py — main interactive application',
    'code/train_model.py — builds and saves the recommendation artifacts',
    'data/movies.csv — bundled movie dataset',
    'artifacts/ — saved TF-IDF vectorizer and matrix',
    'README.md, report and presentation — documentation'
],size=18)
add_code=slide.shapes.add_textbox(Inches(7.25),Inches(4.55),Inches(5.2),Inches(1.55)); tf=add_code.text_frame
p=tf.paragraphs[0]; p.text='pip install -r requirements.txt'; p.font.size=Pt(17); p.font.name='Consolas'; p.font.color.rgb=NAVY
for cmd in ['python code/train_model.py','python code/movie_recommender.py']:
    p=tf.add_paragraph(); p.text=cmd; p.font.size=Pt(17); p.font.name='Consolas'; p.font.color.rgb=NAVY
footer(slide,9)

# 10 limitations/future
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'9. Limitations & Future Scope')
add_bullets(slide,[
    'Limitations: small demo dataset, no real user history, recommendations depend on text quality.',
    'Future: larger real-world dataset, user ratings, collaborative filtering, hybrid models.',
    'Future UI: Streamlit or Flask web application.',
    'Future evaluation: Precision@K, Recall@K and user feedback.'
]); footer(slide,10)

# 11 conclusion
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'10. Conclusion')
add_bullets(slide,[
    'A complete beginner-friendly movie recommender was implemented.',
    'TF-IDF transforms movie text into numerical features.',
    'Cosine similarity ranks movies with similar content.',
    'The project is offline, runnable, explainable and suitable for internship demonstration.'
],size=21); footer(slide,11)

# 12 viva
slide=prs.slides.add_slide(prs.slide_layouts[6]); add_title(slide,'Viva: Quick Questions')
add_bullets(slide,[
    'What technique? → Content-based filtering.',
    'Why TF-IDF? → To convert text to weighted numerical features.',
    'Why cosine similarity? → To compare feature vectors.',
    'What is input? → Movie title.',
    'What is output? → Five similar movies with similarity scores.',
    'Production ready? → No; this is an academic demo.'
],size=18); footer(slide,12)

prs.save(OUT)
print(OUT)
